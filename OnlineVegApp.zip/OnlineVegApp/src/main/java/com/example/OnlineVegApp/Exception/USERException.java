package com.example.OnlineVegApp.Exception;

public class USERException extends Exception {
	private static final long serialVersionUID = 1L;

	public USERException(String message)	{
		super(message);
	}

}
