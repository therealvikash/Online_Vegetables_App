package com.example.OnlineVegApp.Service;

import java.util.List;

import com.example.OnlineVegApp.Entity.Feedback;





public interface IFeedbackService {
	Feedback addFeedback(Feedback fdbk);
	Feedback viewAllFeedbacks(Integer vegetableId);
	Feedback viewFeedback(Integer customerId);

}
