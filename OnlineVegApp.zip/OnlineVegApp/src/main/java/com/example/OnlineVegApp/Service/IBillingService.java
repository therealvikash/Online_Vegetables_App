package com.example.OnlineVegApp.Service;

import com.example.OnlineVegApp.Entity.BillingDetails;
import com.example.OnlineVegApp.Exception.BillNotFoundException;
import com.example.OnlineVegApp.Exception.NoSuchBillException;

public interface IBillingService {
	
	public BillingDetails addBill(BillingDetails bill);
	public BillingDetails updateBill(Integer billingDetails, BillingDetails bill) throws BillNotFoundException;
	public BillingDetails viewBill(Integer bilInteger) throws NoSuchBillException;

}
