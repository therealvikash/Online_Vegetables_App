package com.example.OnlineVegApp.Exception;

public class NameNotFoundException extends RuntimeException {

	private String message;
	public NameNotFoundException(String  message)
	{
		super(message);
    }

}


