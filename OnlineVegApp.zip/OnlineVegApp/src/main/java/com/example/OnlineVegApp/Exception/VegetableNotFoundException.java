package com.example.OnlineVegApp.Exception;

public class VegetableNotFoundException extends RuntimeException{
	VegetableNotFoundException()
	{
	}
		public VegetableNotFoundException(String s)
		{
			super(s);
		}
	}
	
	


