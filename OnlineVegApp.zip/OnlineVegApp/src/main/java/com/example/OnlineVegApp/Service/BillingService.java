package com.example.OnlineVegApp.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.OnlineVegApp.Entity.BillingDetails;
import com.example.OnlineVegApp.Exception.BillNotFoundException;
import com.example.OnlineVegApp.Exception.NoSuchBillException;
import com.example.OnlineVegApp.Repository.IBillingRepository;




@Service
public class BillingService implements IBillingService {
	
	@Autowired
	private IBillingRepository billrepo;

	@Override
	public BillingDetails addBill(BillingDetails bill)  {
		// TODO Auto-generated method stub
	
		BillingDetails saveBill = billrepo.save(bill);
		return saveBill;
	}

	@Override
	public BillingDetails updateBill(Integer billingId, BillingDetails bill) throws BillNotFoundException {
		// TODO Auto-generated method stub
		
		Optional<BillingDetails> opt = billrepo.findById(billingId);
		if (opt.isPresent()) 
		{
			
			BillingDetails bill1 = opt.get();
			bill1.setBillingId(bill.getBillingId());
			bill1.setOrderId(bill.getOrderId());
			bill1.setTransactionMode(bill.getTransactionMode());
			bill1.setTransactionDate(bill.getTransactionDate());
			bill1.setTransactionDate(bill.getTransactionDate());
			bill1.setBillingAddress(bill.getBillingAddress());
			return billrepo.save(bill);
			
		}
		else 
		{
			throw new BillNotFoundException("Bill with given Id does not exists");
		}
	}

	@Override
	public BillingDetails viewBill(Integer bilInteger) throws NoSuchBillException {
		// TODO Auto-generated method stub
		
		Optional<BillingDetails> opt = billrepo.findById(bilInteger);
		if(opt.isPresent())	
		{
		BillingDetails bill = opt.get();
		return bill;
		}
		else 
		{
			throw new NoSuchBillException("Given Billing Id is not available");
		}
		
		
		//return null;
	}

}
