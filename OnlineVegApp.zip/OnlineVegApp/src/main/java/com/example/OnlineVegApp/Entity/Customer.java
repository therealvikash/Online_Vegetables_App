package com.example.OnlineVegApp.Entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="cust_id")
	private Integer customerId;
	@Column
	private String name;
	@Column
	private String mobileNumber;
	@Column
	private String emailId;
	
	@Column
	private String address;
		//@OneToOne(cascade = CascadeType.ALL,fetch=FetchType.LAZY )
	//@JoinColumn(name = "bill")
//	private BillingDetails billingdetails;
		public Integer getCustomerId() {
			return customerId;
		}
		public void setCustomerId(Integer customerId) {
			this.customerId = customerId;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getMobileNumber() {
			return mobileNumber;
		}
		public void setMobileNumber(String mobileNumber) {
			this.mobileNumber = mobileNumber;
		}
		public String getEmailId() {
			return emailId;
		}
		public void setEmailId(String emailId) {
			this.emailId = emailId;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
//		public BillingDetails getBillingdetails() {
//			return billingdetails;
//		}
//		public void setBillingdetails(BillingDetails billingdetails) {
//			this.billingdetails = billingdetails;
//		}
		public Customer(Integer customerId, String name, String mobileNumber, String emailId, String address
				) {
			super();
			this.customerId = customerId;
			this.name = name;
			this.mobileNumber = mobileNumber;
			this.emailId = emailId;
			this.address = address;
			//this.billingdetails = billingdetails;
		}
		public Customer() {
			super();
		}
		@Override
		public String toString() {
			return "Customer [customerId=" + customerId + ", name=" + name + ", mobileNumber=" + mobileNumber
					+ ", emailId=" + emailId + ", address=" + address + "]";
		}
		
		
}
//	@OneToOne(cascade = CascadeType.ALL)
//	@JoinColumn(name = "addressno")
//	private Address addresses;
	
//	@OneToOne(cascade = CascadeType.ALL,fetch=FetchType.LAZY )
//	@JoinColumn(name = "orderno")
//	private Order orderdetails;
//	
//	@OneToOne(cascade = CascadeType.ALL,fetch=FetchType.LAZY )
//	@JoinColumn(name = "cartno")
//	private Cart cartdetails;
//	
//	@OneToMany(cascade = CascadeType.ALL,fetch=FetchType.LAZY , mappedBy = "customer")
//	private List<Feedback> feedbacks;
