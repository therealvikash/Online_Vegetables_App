package com.example.OnlineVegApp.Exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class FeedbackExceptionHandler extends Exception {
	
	public  FeedbackExceptionHandler(String message) {
		super(message);
		
	}
     
	public FeedbackExceptionHandler() {
		
	}
}
