package com.example.OnlineVegApp.Exception;

public class AdminNotFoundException extends RuntimeException
{
	private String message;
	public AdminNotFoundException(String  message)
	{
		super(message);
    }
	

}
