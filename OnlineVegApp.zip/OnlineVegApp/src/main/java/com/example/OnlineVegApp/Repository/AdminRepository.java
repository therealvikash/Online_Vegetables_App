package com.example.OnlineVegApp.Repository;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.OnlineVegApp.Entity.Admin;





@Repository
public interface AdminRepository extends JpaRepository <Admin,Integer>{
	
	
	//public void deleteById(Admin adminId);
	//public void findByAdminId(Admin adminId);
	///public Optional<Admin> findById(Admin adminId);
	

}
