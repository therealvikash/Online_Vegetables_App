package com.example.OnlineVegApp.Service;

import java.util.List;
import java.util.Optional;

import com.example.OnlineVegApp.Entity.Customer;
import com.example.OnlineVegApp.Exception.*;

public interface ICustomerService {
	public Customer addCustomer(Customer customer);
	public Customer updateCustomer(Integer bid, Customer cus);
	public void removeCustomer(Integer cid);
	public Customer viewCustomer( Integer cid) throws NoSuchCustomerException;
	public List<Customer> viewCustomerList(String address);
	public List<Customer> getAllcus();

}



