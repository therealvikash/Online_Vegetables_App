package com.example.OnlineVegApp.Exception;

public class NoSuchCustomerException extends RuntimeException {
	NoSuchCustomerException()
	{
		
	}
	public NoSuchCustomerException(String s)
	{
		super(s);
	}
	

}
