package com.example.OnlineVegApp.Controller;

import java.time.LocalDate;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.OnlineVegApp.Entity.Order;
import com.example.OnlineVegApp.Service.IOrderService;


@RestController
@RequestMapping(value="/Order")
@CrossOrigin(origins = "http://localhost:3000")
public class OrderController {
	@Autowired
	private IOrderService orderService;
	
	@PostMapping(value="/add")
	public  ResponseEntity<Order> addOrder(@Valid @RequestBody Order order) 
	{
	     Order saveOrder = orderService.addOrder(order);
		return new ResponseEntity<Order>(saveOrder,HttpStatus.CREATED);
	}
	
	@PutMapping(value="/{orderNo}")
	public ResponseEntity<Order> updateVegetable(@Valid @PathVariable Integer orderNo,@RequestBody Order order)
	{
		
		Order order1=  orderService.updateOrderDetails(order, orderNo);
		return new ResponseEntity<Order>(order, HttpStatus.CREATED);
			
	}
	
	@GetMapping(value="/vieworder")
	public ResponseEntity<List<Order>>viewOrderList()
	{
		
		 List<Order> viewVegetable=orderService.viewOrderList();
		return new  ResponseEntity<List<Order>>(viewVegetable,HttpStatus.OK);
    }
	
	@GetMapping(value="/vieworder/{customerId}")
	public ResponseEntity<Order> viewAllOrder(@Valid @PathVariable Integer customerId)
	{
		
		 Order vieworder=orderService.viewAllOrders(customerId);
		return new  ResponseEntity<Order>(vieworder,HttpStatus.OK);
	}
	
//	@GetMapping(value="/vieworderbydate/{date}")
//	public ResponseEntity<List<Order>> viewAllOrdersByDate(@Valid @PathVariable LocalDate date)
//	{
//		
//		 List<Order> vieworderbydate =orderService.viewAllOrders(date);
//		return new  ResponseEntity<List<Order>>(vieworderbydate,HttpStatus.OK);
//	}
	
//	@GetMapping(value="/vieworderbydate/{date}")
//	public ResponseEntity<List<Order>> viewOrderList()
//	{
//		
//		 List<Order> vieworderList =orderService.viewOrderList();
//		return new  ResponseEntity<List<Order>>(vieworderList,HttpStatus.OK);
//	}
	
	@DeleteMapping(value="/orderNo/{orderNo}")
	public ResponseEntity<String> removeVegetable(@Valid @PathVariable Integer orderNo)
	{
		orderService.cancelOrder(orderNo);
		String msg="order deleted successfully";
		return new ResponseEntity<String>(msg, HttpStatus.OK);
	}
	
	
	
	
	
	

}
