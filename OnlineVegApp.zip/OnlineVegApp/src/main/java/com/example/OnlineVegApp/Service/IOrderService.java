package com.example.OnlineVegApp.Service;

import java.time.LocalDate;
import java.util.List;

import com.example.OnlineVegApp.Entity.Order;



public interface IOrderService {
	
	Order addOrder(Order order);
	
	Order updateOrderDetails(Order order,Integer orderNo);
 Order viewAllOrders(int custid);
//	List<Order> viewAllOrders(LocalDate date);
	List<Order> viewOrderList();
	 void cancelOrder(int orderid);

}
