package com.example.OnlineVegApp.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.OnlineVegApp.Entity.VegetableDTO;



@Repository
public interface IVegetableDTORepo extends JpaRepository<VegetableDTO,Integer>{

	public void deleteById(Integer vid);
	//public VegetableDTO updateVegetable(VegetableDTO dto);
	List<VegetableDTO> findAll();
	public List<VegetableDTO> findByName(String name);
	
	
	@Query("FROM VegetableDTO  WHERE category=?1")
	public List<VegetableDTO> find(@Param("category") String category);
	
	
	
	
	 //@Query("SELECT v FROM VegetableDTO v  WHERE v.name=name")
	//public List<VegetableDTO> findByName(@Param("name") String name);
}
