package com.example.OnlineVegApp.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="feedback")
public class Feedback {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private Integer feedbackId;
	@Column
	@NotNull(message = "VegetableId  is Required!")
	private Integer vegetableId;
	@Column
	@NotNull(message = "CustomerId is Required!")
	private Integer customerId;
	@Column
	@NotNull(message = "rating is Required!")
	private Integer rating;
	@Column
	@NotEmpty(message = "Comment is Required!")
	private String comments;
	public Feedback(Integer feedbackId, Integer vegetableId, Integer customerId, Integer rating, String comments) {
		
		this.feedbackId = feedbackId;
		this.vegetableId = vegetableId;
		this.customerId = customerId;
		this.rating = rating;
		this.comments = comments;
	}
	public Feedback() {
		super();
	}
	public Integer getFeedbackId() {
		return feedbackId;
	}
	public void setFeedbackId(Integer feedbackId) {
		this.feedbackId = feedbackId;
	}
	public Integer getVegetableId() {
		return vegetableId;
	}
	public void setVegetableId(Integer vegetableId) {
		this.vegetableId = vegetableId;
	}
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public Integer getRating() {
		return rating;
	}
	public void setRating(Integer rating) {
		this.rating = rating;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	@Override
	public String toString() {
		return "Feedback [feedbackId=" + feedbackId + ", vegetableId=" + vegetableId + ", customerId=" + customerId
				+ ", rating=" + rating + ", comments=" + comments + "]";
	}
	
	
	
	

}
