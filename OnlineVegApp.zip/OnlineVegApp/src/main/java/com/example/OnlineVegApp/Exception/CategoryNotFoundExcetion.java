package com.example.OnlineVegApp.Exception;

public class CategoryNotFoundExcetion extends RuntimeException{
	private String message;
	public CategoryNotFoundExcetion(String  message)
	{
		super();
    }
}
