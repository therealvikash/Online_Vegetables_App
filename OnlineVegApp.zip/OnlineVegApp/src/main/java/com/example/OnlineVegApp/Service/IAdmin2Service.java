package com.example.OnlineVegApp.Service;

public interface IAdmin2Service {
	public boolean login(String name, String password);

}
