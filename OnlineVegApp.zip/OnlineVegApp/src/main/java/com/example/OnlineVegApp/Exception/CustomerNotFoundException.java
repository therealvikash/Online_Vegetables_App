package com.example.OnlineVegApp.Exception;


public class CustomerNotFoundException extends RuntimeException{
	CustomerNotFoundException()
	{
	}
		public CustomerNotFoundException(String s)
		{
			super(s);
			
		}

}