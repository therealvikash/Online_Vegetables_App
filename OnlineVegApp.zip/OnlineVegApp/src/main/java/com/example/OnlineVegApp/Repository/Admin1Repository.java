package com.example.OnlineVegApp.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.OnlineVegApp.Entity.Admin1;


@Repository
public interface Admin1Repository extends JpaRepository<Admin1,String> {

	Optional<Admin1> findByNameAndPassword(String name, String password);
	
//	public Optional<Admin1> findByNameAndPassword(String name,String password);
	

}
