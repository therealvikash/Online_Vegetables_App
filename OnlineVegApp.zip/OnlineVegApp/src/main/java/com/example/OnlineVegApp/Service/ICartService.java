package com.example.OnlineVegApp.Service;

import java.util.List;

import com.example.OnlineVegApp.Entity.Cart;



public interface ICartService {
	
	Cart addToCart(Cart veg);
	
	void removeVegetable(int id);
	void removeAllVegetables();
	List<Cart> viewAllItems();
	

}
