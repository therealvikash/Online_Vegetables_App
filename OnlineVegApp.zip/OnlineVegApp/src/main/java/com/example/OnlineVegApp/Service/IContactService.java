package com.example.OnlineVegApp.Service;

import com.example.OnlineVegApp.Entity.Contact;

public interface IContactService {

	Contact saveContact(Contact contact);
}
