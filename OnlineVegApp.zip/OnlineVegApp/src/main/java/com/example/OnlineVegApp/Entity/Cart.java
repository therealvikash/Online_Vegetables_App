package com.example.OnlineVegApp.Entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
@Entity
public class Cart {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer  cartId;
	@Column
	private Integer customerId;
	@Column
	private String vegetable;
	public Cart(Integer cartId, Integer customerId, String vegetable) {
		super();
		this.cartId = cartId;
		this.customerId = customerId;
		this.vegetable = vegetable;
	}
	public Cart() {
		super();
	}
	public Integer getCartId() {
		return cartId;
	}
	public void setCartId(Integer cartId) {
		this.cartId = cartId;
	}
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public String getVegetable() {
		return vegetable;
	}
	public void setVegetable(String vegetable) {
		this.vegetable = vegetable;
	}
	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", customerId=" + customerId + ", vegetable=" + vegetable + "]";
	}
	
	
	
	
	
	
	
	
	
	

}
