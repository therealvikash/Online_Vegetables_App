package com.example.OnlineVegApp.Entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Login1 {
	private String name;
	private String password;
	
	@Override
	public String toString() {
		return "Login1 [name=" + name + ", password=" + password + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Login1() {
		super();
	}
	public Login1(String name, String password) {
		super();
		this.name=name;
		this.password = password;
	}

}
