package com.example.OnlineVegApp.Exception;

public class NoSuchBillException extends RuntimeException
{
	private String message;
	public NoSuchBillException(String message) {
		super(message);
		this.message=message;
	}
	public NoSuchBillException() {
		
	}
	

}
