package com.example.OnlineVegApp.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
@Entity
public class Admin {
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	@Id
	private Integer adminId;
	@Column
	@NotEmpty(message="Admin name is required")
	private String name;
	@Column
	@NotEmpty(message="email is required")
	private String email;
	@Column
	@NotNull(message=" ContactNumber is required")
	private String contactNumber;
	
	public Admin(Integer adminId, @NotEmpty(message = "Admin name is required") String name,
			@NotEmpty(message = "email is required") String email,
			@NotNull(message = " ContactNumber is required") String contactNumber) {
		super();
		this.adminId = adminId;
		this.name = name;
		this.email = email;
		this.contactNumber = contactNumber;
	}
	public Admin() {
		super();
	}
	public Integer getAdminId() {
		return adminId;
	}
	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", name=" + name + ", email=" + email + ", contactNumber=" + contactNumber
				+ "]";
	}
	
	

}
