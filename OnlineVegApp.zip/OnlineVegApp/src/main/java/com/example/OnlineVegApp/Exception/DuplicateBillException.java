package com.example.OnlineVegApp.Exception;

public class DuplicateBillException extends RuntimeException {
	private String message;

	public  DuplicateBillException(String message) {
		super(message);
		this.message=message;
	}
     
	public DuplicateBillException () {
		
	}

}
