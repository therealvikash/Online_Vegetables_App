package com.example.OnlineVegApp.Entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="order_table")
public class Order {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private Integer orderNo;
	@Column
	@NotNull(message = "customerId is Required!")
	private Integer customerId;
	@Column
	@NotNull(message = "select vegetable!")
	 private String vegetableList;
	@Column
	@NotNull(message = "totalAmount required!")
	private Double totalAmount;
	@Column
	private String status;
	public Integer getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(Integer orderNo) {
		this.orderNo = orderNo;
	}
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public String getVegetableList() {
		return vegetableList;
	}
	public void setVegetableList(String vegetableList) {
		this.vegetableList = vegetableList;
	}
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Order(Integer orderNo, Integer customerId, String vegetableList, Double totalAmount,
			String status) {
		super();
		this.orderNo = orderNo;
		this.customerId = customerId;
		this.vegetableList = vegetableList;
		this.totalAmount = totalAmount;
		this.status = status;
	}
	public Order() {
		super();
	}
	@Override
	public String toString() {
		return "Order [orderNo=" + orderNo + ", customerId=" + customerId + ", vegetableList=" + vegetableList
				+ ", totalAmount=" + totalAmount + ", status=" + status + "]";
	}
	
	
	

}
