package com.example.OnlineVegApp.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.OnlineVegApp.Entity.Admin1;
import com.example.OnlineVegApp.Repository.Admin1Repository;


@Service
public class Admin1Service<adminRepo> implements IAdmin2Service{
	@Autowired
	private  Admin1Repository adminRepo;

	@Override
	public boolean login(String name, String password) {
		// TODO Auto-generated method stub
		Optional<Admin1> opt= adminRepo.findByNameAndPassword(name, password);
		if(opt.isPresent())
		{
			return true;
		}
		return false;
	}

}
