package com.example.OnlineVegApp.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import com.example.OnlineVegApp.Entity.VegetableDTO;
import com.example.OnlineVegApp.Exception.CategoryNotFoundExcetion;
import com.example.OnlineVegApp.Exception.NameNotFoundException;
import com.example.OnlineVegApp.Exception.VegetableNotFoundException;
import com.example.OnlineVegApp.Repository.IVegetableDTORepo;


@Service
public class VegetableDTOServiceImpl implements IVegetableDTOService{

	@Autowired
	private IVegetableDTORepo iVegetableDTORepo;
	@Override
	public VegetableDTO addVegetable(VegetableDTO dto) {
		// TODO Auto-generated method stub
		VegetableDTO saveVegetable=iVegetableDTORepo.save(dto);
		return saveVegetable;
	}
	@Override
	public void removeVegetable(Integer vid) throws VegetableNotFoundException{
		Optional<VegetableDTO> opt = iVegetableDTORepo.findById(vid);
		if(opt.isPresent()) {
		iVegetableDTORepo.deleteById(vid);
		}
		else{
			throw new  VegetableNotFoundException("Vegetable with Given ID:"+vid+ "Not Available");
		}
		
		// TODO Auto-generated method stub
		
	}
	@Override
	public VegetableDTO viewVegetable(Integer vid)throws VegetableNotFoundException{
		// TODO Auto-generated method stub
		Optional<VegetableDTO> opt=iVegetableDTORepo.findById(vid);
		if(opt.isPresent()) {
		VegetableDTO vegetable=opt.get();
		return vegetable;
		}
		else{
			throw new  VegetableNotFoundException("Vegetable with Given ID:"+vid+ "Not Available");
		}
		
	}
	@Override
	public List<VegetableDTO> viewAllVegetables() {
		// TODO Auto-generated method stub
		List<VegetableDTO> viewVeg=iVegetableDTORepo.findAll();
		return viewVeg;
	}
	@Override
	public VegetableDTO updateVegetable(Integer vid,VegetableDTO dto) {
		// TODO Auto-generated method stub
		
		Optional<VegetableDTO> opt = iVegetableDTORepo.findById(vid);
		if(opt.isPresent())
		{
			VegetableDTO veget1=opt.get();
			veget1.setCategory(dto.getCategory());
			veget1.setName(dto.getName());
			veget1.setPrice(dto.getPrice());
			veget1.setQuantity(dto.getQuantity());
			veget1.setType(dto.getType());
			return iVegetableDTORepo.save(veget1);
		}
		else
		{
			return iVegetableDTORepo.save(dto);
		}
		
	}
	@Override
	public List<VegetableDTO> viewVegetableList(String category)throws CategoryNotFoundExcetion {
		return iVegetableDTORepo.find(category);
	
		
		
	}
	
	public List<VegetableDTO> viewVegetableByName(String name) throws NameNotFoundException{
		// TODO Auto-generated method stub
		return iVegetableDTORepo.findByName(name);
		
			
		
	}
	       
		
	}

	
