package com.example.OnlineVegApp.Service;

public interface IUserService {
	public boolean login(String username, String password);

}
