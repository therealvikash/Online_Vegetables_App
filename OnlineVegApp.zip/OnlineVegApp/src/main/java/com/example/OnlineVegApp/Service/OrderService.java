package com.example.OnlineVegApp.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.OnlineVegApp.Entity.Order;
import com.example.OnlineVegApp.Exception.OrderNotFoundException;
import com.example.OnlineVegApp.Repository.IOrderRepository;



@Service
public class OrderService implements IOrderService {
	
	@Autowired 
	private IOrderRepository orderRepo;

	@Override
	public Order addOrder(Order order) {
		Order saveOrder = orderRepo.save(order);
		return order;
	}


		


		
	

	@Override
	public Order updateOrderDetails(Order order, Integer orderno) {
		
		Optional<Order> opt = orderRepo.findById(orderno);
		if(opt.isPresent())
		{
			Order order1=opt.get();
			order1.setOrderNo(order.getOrderNo());
			order1.setCustomerId(order.getCustomerId());
			order1.setVegetableList(order.getVegetableList());
			order1.setTotalAmount(order.getTotalAmount());
			order1.setStatus(order.getStatus());
			return orderRepo.save(order1);
		}
		else
		{
			return orderRepo.save(order);
		}
		
	}

@Override
	public Order  viewAllOrders(int custid) {
		
		
		Optional<Order> opt = orderRepo.findById(custid);
		if(opt.isPresent())
		{
			Order order1 = opt.get();
			return order1;
		}
		else
		{
			throw new OrderNotFoundException("Order Not Available");
		}
		
	}

//	@Override
//	public List<Order> viewAllOrders(LocalDate date) {
//		
//		return orderRepo.findByDate();
//	}

	@Override
	public List<Order> viewOrderList() {
		
		return orderRepo.findAll();
	}

	@Override
	
	public void cancelOrder(int orderNo) {
		
		orderRepo.deleteById(orderNo);;
		
	}

	

}
