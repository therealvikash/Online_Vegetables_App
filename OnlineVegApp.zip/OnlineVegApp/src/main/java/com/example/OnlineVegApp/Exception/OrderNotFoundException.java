package com.example.OnlineVegApp.Exception;

public class OrderNotFoundException extends RuntimeException{
	private String s;
	
	public OrderNotFoundException(String s)
	{
		
		this.s=s;
	}
	OrderNotFoundException()
	{
	}
	}


