package com.example.OnlineVegApp.Service;

import java.util.List;

import com.example.OnlineVegApp.Entity.VegetableDTO;
import com.example.OnlineVegApp.Exception.CategoryNotFoundExcetion;
import com.example.OnlineVegApp.Exception.NameNotFoundException;



public interface IVegetableDTOService {


	public VegetableDTO addVegetable(VegetableDTO dto);
	public VegetableDTO updateVegetable(Integer vid,VegetableDTO dto);
	public void removeVegetable(Integer vid);
	public VegetableDTO viewVegetable(Integer vid);
	public List<VegetableDTO> viewAllVegetables();
	public List<VegetableDTO> viewVegetableList(String category)throws CategoryNotFoundExcetion;
	public List<VegetableDTO> viewVegetableByName(String name)throws NameNotFoundException;
	
}
