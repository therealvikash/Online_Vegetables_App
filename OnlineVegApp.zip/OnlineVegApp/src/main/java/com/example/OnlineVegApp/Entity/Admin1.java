package com.example.OnlineVegApp.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Admin1 {
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	@Id
	private Integer adminId;
	@Column
	//@NotEmpty(message="Admin name is required")
	private String name;
	@Column
	//@NotEmpty(message="email is required")
	private String password ;

	@Column
	//@NotEmpty(message="email is required")
	private String email;
	@Column
	//@NotNull(message=" ContactNumber is required")
	private String contactNumber;
	public Integer getAdminId() {
		return adminId;
	}
	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public Admin1(Integer adminId, String name, String password, String email, String contactNumber) {
		super();
		this.adminId = adminId;
		this.name = name;
		this.password = password;
		this.email = email;
		this.contactNumber = contactNumber;
	}
	public Admin1() {
		super();
	}
	@Override
	public String toString() {
		return "Admin1 [adminId=" + adminId + ", name=" + name + ", password=" + password + ", email=" + email
				+ ", contactNumber=" + contactNumber + "]";
	}
	
}
