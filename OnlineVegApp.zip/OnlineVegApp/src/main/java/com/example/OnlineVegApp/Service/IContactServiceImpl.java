package com.example.OnlineVegApp.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.OnlineVegApp.Entity.Contact;
import com.example.OnlineVegApp.Entity.Customer;
import com.example.OnlineVegApp.Repository.IContactRepository;

@Service
public class IContactServiceImpl implements IContactService{
@Autowired
private IContactRepository conrepo;
@Override
public Contact saveContact(Contact contact)
{
	Contact addCon=conrepo.save(contact);
return addCon;

	
}
}
