package com.example.OnlineVegApp.Exception;

public class BillNotFoundException extends RuntimeException {
	private String message;

	public  BillNotFoundException(String message) {
		super(message);
		this.message=message;
	}
     
	public BillNotFoundException () {
		
	}

}
