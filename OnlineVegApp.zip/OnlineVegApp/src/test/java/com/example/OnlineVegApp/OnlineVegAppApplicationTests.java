package com.example.OnlineVegApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineVegAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
